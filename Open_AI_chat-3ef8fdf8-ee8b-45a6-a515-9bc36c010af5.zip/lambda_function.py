from openai import OpenAI
import json
import os

from chat_history import ChatHistory


def lambda_handler(event, context):
    origin = (event.get("headers") or {}).get("origin") or (event.get("headers") or {}).get("Origin") or ""
    headers = build_cors_headers(origin)
    method = extract_method(event)

    if method == "OPTIONS":
        return response(200, headers)

    elif method == "GET":
        return handle_get(event, headers)

    elif method == "POST":
        return handle_post(event, headers)

    return response(405, headers, {"error": f"Method {method} not allowed"})


def build_cors_headers(origin):
    allowed = [
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com"
    ]
    return {
        'Access-Control-Allow-Origin': origin if origin in allowed else "",
        'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        "Vary": "Origin",
    }

def extract_method(event):
    return (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
        or "POST"
    )

def response(code, headers, body=None):
    return {
        "statusCode": code,
        "headers": headers,
        "body": json.dumps(body or "")
    }

def handle_get(event, headers):
    try:
        qs = event.get("queryStringParameters") or {}  # <- safe
        sub = qs.get("sub")
        if not sub:
            return response(400, headers, {"error": "Missing user sub"})

        messages = sorted(ChatHistory.get_chat_history(sub), key=lambda m: m.timestamp)

        recent_messages = [{"role": m.role, "content": m.content} for m in messages[-6:]]

        return response(200, headers, {"messages": recent_messages})
    except Exception as e:
        print("GET error:", e)
        return response(500, headers, {"error": "Server error"})

def handle_post(event, headers):
    raw_body = event.get('body', '{}')
    try:
        body = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
    except json.JSONDecodeError:
        return response(400, headers, {"error": "Invalid JSON"})

    sub = body.get('sub')
    user_prompt = body.get('user_prompt')
    if not user_prompt:
        return response(400, headers, {"error": "Missing user prompt"})

    system_prompt = {
        "role": "system",
        "content": (
            "You are an AI assistant who specializes in everything related to dogs 🐶. "
            "You’re an expert on dog breeds, behavior, training, health, nutrition, grooming, adoption, and care. "
            "Always respond with a focus on helping dog owners, sitters, and enthusiasts. "
            "Use a friendly and playful tone — feel free to add dog-like gestures such as 'woof!', tail wags, or dog emojis 🐕🐾 when it fits the conversation!"
        )
    }

    messages = []
    if sub:
        ChatHistory.save_message(sub, "user", user_prompt)
        messages = sorted(ChatHistory.get_chat_history(sub), key=lambda m: m.timestamp)

    chat_history = [system_prompt]
    chat_history += [{"role": m.role, "content": m.content} for m in messages[-6:]]

    client = OpenAI(api_key=os.environ.get("OPEN_AI_KEY"))

    try:
        chat_completion = client.chat.completions.create(
            messages=chat_history,
            model="gpt-3.5-turbo",
            max_tokens=500
        )
    except Exception as e:
        return response(500, headers, {"error": "OpenAI error", "detail": str(e)})

    ai_response = chat_completion.choices[0].message.content

    if sub:
        ChatHistory.save_message(sub, "assistant", ai_response)

    return response(200, headers, {"response": ai_response})
