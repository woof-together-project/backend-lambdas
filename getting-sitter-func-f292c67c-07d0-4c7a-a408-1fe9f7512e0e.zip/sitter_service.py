import os
import math
import requests
from db import SessionLocal, Base
from sqlalchemy import Column, Integer, String, Boolean, DateTime, DECIMAL, ForeignKey
from sqlalchemy import func
from datetime import datetime, timezone


class User(Base):
    __tablename__ = 'Users'
    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    RegistrationDate = Column(DateTime, nullable=False)
    City = Column(String(50), nullable=False)
    Street = Column(String(50))
    IsCompleted = Column(Boolean, nullable=False, default=False)
    Latitude = Column(DECIMAL(18, 10), nullable=True)
    Longitude = Column(DECIMAL(18, 10), nullable=True)

class Sitter(Base):
    __tablename__ = 'Sitters'
    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    ExperienceYears = Column(Integer, nullable=False)
    Availability = Column(String(500), nullable=False)
    Rate = Column(DECIMAL(18, 0), nullable=False)
    HowManyRated = Column(Integer, nullable=False)
    ReviewsCount = Column(Integer, nullable=False)
    AboutMe = Column(String, nullable=False)
    ExperienceDetails = Column(String, nullable=False)
    ServiceOptions = Column(String(500), nullable=False)
    ProfilePictureUrl = Column(String(1024), nullable=True)
    Gender = Column(String(50), nullable=True)
    Active = Column(Boolean, nullable=False, default=True)


class Review(Base):
    __tablename__ = 'Reviews'
    id = Column(Integer, primary_key=True, autoincrement=True)
    sitter_id = Column(Integer, ForeignKey("Sitters.Id"), nullable=False)
    user_id = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    rating = Column(DECIMAL(18, 0), nullable=False)
    comment = Column(String(1000))
    review_date = Column(DateTime, nullable=False)



class SitterService:

    @staticmethod
    def haversine(lat1, lon1, lat2, lon2):
        R = 6371  # Earth radius in km
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = (
            math.sin(d_lat / 2) ** 2 +
            math.cos(math.radians(lat1)) *
            math.cos(math.radians(lat2)) *
            math.sin(d_lon / 2) ** 2
        )
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    @staticmethod
    def geocode_address(city, street):
        full_address = f"{street or ''}, {city}"
        params = {
            'address': full_address,
            'key': os.getenv("GOOGLE_MAPS_API_KEY")
        }
        response = requests.get("https://maps.googleapis.com/maps/api/geocode/json", params=params)
        data = response.json()
        if data['status'] == 'OK' and data['results']:
            location = data['results'][0]['geometry']['location']
            return location['lat'], location['lng']
        return None, None
    
    @classmethod
    def get_sitters_matching_criteria(cls, payload):
        try:
            with SessionLocal() as session:
                latitude = float(payload.get("latitude"))
                longitude = float(payload.get("longitude"))
                radius = float(payload.get("radius", 0))
                use_radius = not payload.get("noRadiusFilter", False)
                print(f"Radius: {radius}, Use Radius: {use_radius}")

                selected_services   = set(s.strip().lower() for s in payload.get("serviceOptions", []))
                selected_experience = set(s.strip().lower() for s in payload.get("experienceTypes", []))
                selected_gender     = (payload.get("sitterGender") or "any").lower()
                max_rate            = float(payload.get("maxRate", 9999))

                rev_agg = (
                    session.query(
                        Review.sitter_id.label("sid"),
                        func.count(Review.id).label("reviewCount"),
                        func.coalesce(func.avg(Review.rating), 0).label("averageRating"),
                    )
                    .group_by(Review.sitter_id)
                    .subquery()
                )

                q = (
                    session.query(
                        Sitter,
                        User,
                        func.coalesce(rev_agg.c.reviewCount, 0).label("reviewCount"),
                        func.coalesce(rev_agg.c.averageRating, 0).label("averageRating"),
                    )
                    .join(User, Sitter.UserId == User.Id)
                    .outerjoin(rev_agg, rev_agg.c.sid == Sitter.Id)
                    .filter(Sitter.Active == True)
                )

                rows = q.all()
                result = []
                for sitter, user, review_count, average_rating in rows:
                    if not user or user.Latitude is None or user.Longitude is None:
                        continue

                    # Rate
                    if sitter.Rate is not None and float(sitter.Rate) > max_rate:
                        continue

                    # Services
                    sitter_services = set(s.strip().lower() for s in (sitter.ServiceOptions or "").split(",") if s.strip())
                    if selected_services and not selected_services.issubset(sitter_services):
                        continue

                    # Experience
                    sitter_experience = set(s.strip().lower() for s in (sitter.ExperienceDetails or "").split(",") if s.strip())
                    if selected_experience and not selected_experience.issubset(sitter_experience):
                        continue

                    # Gender 
                    if selected_gender != "any":
                        s_gender = (sitter.Gender or "").lower()
                        if s_gender != selected_gender:
                            continue

                    # Distance
                    distance = cls.haversine(latitude, longitude, float(user.Latitude), float(user.Longitude))
                    print(f"Distance: {distance}")
                    if use_radius and distance > radius:
                        continue

                    result.append({
                        'user_id': sitter.UserId,
                        'sitterId': sitter.Id,
                        'name': user.Name,
                        'email': user.Email,
                        'profilePictureUrl': sitter.ProfilePictureUrl,
                        'experienceYears': sitter.ExperienceYears,
                        'availability': sitter.Availability,
                        'rate': str(sitter.Rate) if sitter.Rate is not None else None,
                        'aboutMe': sitter.AboutMe,
                        'moreDetails': sitter.ExperienceDetails,
                        'city': user.City,
                        'street': user.Street,
                        'distanceKm': round(distance, 2),
                        'latitude': float(user.Latitude),
                        'longitude': float(user.Longitude),
                        'reviewCount': int(review_count or 0),
                        'averageRating': float(average_rating or 0),
                        'serviceOptions': [s.strip() for s in (sitter.ServiceOptions or "").split(",") if s.strip()],
                        'experienceDetails': [s.strip() for s in (sitter.ExperienceDetails or "").split(",") if s.strip()],
                        'imageUrl': None,
                    })

                result.sort(key=lambda x: x["distanceKm"])
                return result

        except Exception as e:
            print("Error while filtering sitters:", str(e))
            return []


    @classmethod
    def get_all_sitter_cities(cls, payload= None):
        try:
            with SessionLocal() as session:
                cities = (
                session.query(User.City)
                .join(Sitter, Sitter.UserId == User.Id)
                .filter(User.City != None, Sitter.Active == True) 
                .distinct()
                .all()
)

            return sorted(list({city[0].strip() for city in cities if city[0]}))

        except Exception as e:
            print("Error fetching cities:", str(e))
            return []


    @classmethod
    def get_sitters_by_city(cls, payload):
        try:
            city = (payload.get("city") or "").strip().lower()
            latitude = float(payload.get("latitude") or 0)
            longitude = float(payload.get("longitude") or 0)
            exclude_email = ((payload.get("excludeEmail")
                          or payload.get("exclude_email")
                          or "")).strip().lower()
                          
            if not city:
                return []

            with SessionLocal() as session:
                rows = (
                    session.query(Sitter, User)
                    .join(User, Sitter.UserId == User.Id)
                    .filter(
                        Sitter.Active == True,
                        func.lower(User.City).like(f"%{city}%")
                    )
                    .all()
                )

                result = []
                for sitter, user in rows:
                    if user.Latitude is None or user.Longitude is None:
                        continue

                    if exclude_email and (user.Email or "").strip().lower() == exclude_email:
                        continue

                    distance = cls.haversine(
                        latitude, longitude,
                        float(user.Latitude), float(user.Longitude)
                    )

                    rc, avg = session.query(
                        func.count(Review.id),
                        func.coalesce(func.avg(Review.rating), 0)
                    ).filter(Review.sitter_id == sitter.Id).one()

                    result.append({
                        'user_id': sitter.UserId,
                        'sitterId': sitter.Id,
                        'name': user.Name,
                        'email': user.Email,
                        'profilePictureUrl': sitter.ProfilePictureUrl,
                        'experienceYears': sitter.ExperienceYears,
                        'availability': sitter.Availability,
                        'rate': str(sitter.Rate) if sitter.Rate is not None else None,
                        'aboutMe': sitter.AboutMe,
                        'moreDetails': sitter.ExperienceDetails,
                        'city': user.City,
                        'street': user.Street,
                        'latitude': float(user.Latitude),
                        'longitude': float(user.Longitude),
                        'distanceKm': round(distance, 2),
                        'reviewCount': int(rc or 0),
                        'averageRating': float(avg or 0),
                        'serviceOptions': [s.strip() for s in (sitter.ServiceOptions or "").split(",") if s.strip()],
                        'experienceDetails': [s.strip() for s in (sitter.ExperienceDetails or "").split(",") if s.strip()],
                        'imageUrl': None
                    })

                result.sort(key=lambda x: x['distanceKm'])
                return result

        except Exception as e:
            print("Error in get_sitters_by_city:", str(e))
            return []
        
    @classmethod
    def get_reviews_for_sitter(cls, sitter_id: int):
        with SessionLocal() as session:
            sitter = session.query(Sitter).filter(Sitter.Id == sitter_id).first()
            if not sitter:
                return {"reviews": [], "average": 0.0, "count": 0}

            rows = (
            session.query(
                Review,
                User.Name.label("user_name"),
                User.Email.label("user_email"),
            )
            .join(User, Review.user_id == User.Id)
            .filter(Review.sitter_id == sitter.Id)
            .order_by(Review.review_date.desc()) 
            .all()
        )

            reviews_payload = [{
            "id": rev.id,
            "sitterId": rev.sitter_id,
            "userId": rev.user_id,
            "userName": user_name or "Anonymous",
            "rating": float(rev.rating),
            "comment": rev.comment,
            "reviewDate": rev.review_date.replace(tzinfo=timezone.utc).isoformat()
        } for (rev, user_name, user_email) in rows]

        avg = (sum(float(rev.rating) for (rev, _, _) in rows) / len(rows)) if rows else 0.0
        return {"reviews": reviews_payload, "average": avg, "count": len(reviews_payload)}

    @classmethod
    def add_review(cls, sitter_id: int, user_email: str, rating: float, comment: str):
        if rating < 1 or rating > 5:
            raise Exception("Rating must be between 1 and 5")

        with SessionLocal() as session:
            user = session.query(User).filter(User.Email == user_email).first()
            if not user:
                raise Exception(f"No user found with email {user_email}")

            sitter = session.query(Sitter).filter(Sitter.Id == sitter_id).first()
            if not sitter:
                raise Exception(f"No sitter record found for sitterId {sitter_id}")

            # Create review
            r = Review(
                sitter_id=sitter.Id,
                user_id=user.Id,
                rating=rating,
                comment=comment,
                review_date=datetime.now(timezone.utc)
            )
            session.add(r)
            session.flush()  

            counts = session.query(
                func.count(Review.id),
                func.coalesce(func.avg(Review.rating), 0)
            ).filter(Review.sitter_id == sitter.Id).one()

            sitter.ReviewsCount = int(counts[0] or 0)
            sitter.HowManyRated = sitter.ReviewsCount 

            session.commit()

        return cls.get_reviews_for_sitter(sitter_id)

    @staticmethod
    def get_user_location(email: str | None):
        """Return the current user's saved lat/lng from Users table."""
        if not email:
            return None
        with SessionLocal() as session:
            user = (
                session.query(User)
                .filter(func.lower(User.Email) == email.strip().lower())
                .first()
            )
            if not user or user.Latitude is None or user.Longitude is None:
                return None
            return {"lat": float(user.Latitude), "lng": float(user.Longitude)}
