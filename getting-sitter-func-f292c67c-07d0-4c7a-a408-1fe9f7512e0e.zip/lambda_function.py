import json
from sitter_service import SitterService

def lambda_handler(event, context):
    origin = event.get("headers", {}).get("origin", "")
    
    allowed = [
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com"
    ]
    
    headers = {
        "Access-Control-Allow-Origin": origin if origin in allowed else "",
        "Access-Control-Allow-Methods": "DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Toke"
    }

    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": ""
        }


    try:
        body = json.loads(event.get("body", "{}"))
        action = body.get("action")

        if action == "getMyLocation":
            loc = SitterService.get_user_location(body.get("email"))
            if not loc:
                return {
                    "statusCode": 404,
                    "headers": headers,
                    "body": json.dumps({"message": "No saved location for this user"})
                }
            return {"statusCode": 200, "headers": headers, "body": json.dumps(loc)}


        elif action == "getReviews":
            sitters = SitterService.get_reviews_for_sitter(int(body["sitterId"]))

        elif action == "addReview":
            sitters = SitterService.add_review(
                sitter_id=int(body["sitterId"]),
                user_email=body["userEmail"],
                rating=float(body["rating"]),
                comment=body.get("comment", "").strip()
            )

        elif action == "searchAvailableCitiesInDB":
            sitters = SitterService.get_all_sitter_cities(body)
        
        elif action == "searchByCity":
            sitters = SitterService.get_sitters_by_city(body)
        
        else:
            required_keys = ["latitude", "longitude"]
            if not all(k in body for k in required_keys):
                raise Exception("Missing location coordinates")

            sitters = SitterService.get_sitters_matching_criteria(body)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(sitters)
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({
                "error": "Could not retrieve sitters",
                "detail": str(e)
            })
        }