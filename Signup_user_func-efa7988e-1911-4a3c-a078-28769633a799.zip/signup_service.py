from db import SessionLocal
from user_service import User, Sitter, Dog
import datetime
import requests
import os
import re
import hashlib
from decimal import Decimal, ROUND_HALF_UP

class SignupService:
    @staticmethod
    def complete_signup(email: str, signup_data: dict) -> str:
        print(f"Lambda execution started for email: {email}")
        print(f"Received signup data: {signup_data}")

        if not (signup_data.get("isSitter") or (signup_data.get("addDog") and signup_data.get("dogs"))):
            return {
                "success": False,
                "isComplete": False,
                "message": "You must add a dog or mark yourself as a sitter to complete signup."
            }, 200

        with SessionLocal() as session:
            try:
                user = session.query(User).filter_by(Email=email).first()
                print(f"isCompleted: {user.IsCompleted if user else 'No user found'}")

                if not user:
                    return {
                        "success": False,
                        "message": f"No user found with email: {email}",
                        "isComplete": False
                    }, 404

                user.Phone = signup_data.get("phone")
                user.City = signup_data.get("city") or ""
                user.Street = signup_data.get("street") or ""
                
                print(f"Street user: {user.Street}")
                print(f"City user: {user.City}")

                try:
                    if user.City and user.Street:
                        print(f"Attempting to geocode: {user.Street}, {user.City}")
                        lat, lng = SignupService.geocode_address(user.City, user.Street)
                        user.Latitude = Decimal(str(lat))
                        user.Longitude = Decimal(str(lng))
                        print(f"Geocoding successful: {lat}, {lng}")
                except Exception as e:
                    print(f"Geocoding exception: {str(e)}")


                added_sitter = False
                added_dogs   = 0

                if signup_data.get("isSitter") and signup_data.get("sitterDetails"):
                    s = signup_data["sitterDetails"]
                    session.add(Sitter(
                        UserId=user.Id,
                        ExperienceYears=int(s["experience"]),
                        Availability=s["availability"],
                        Rate=s.get("rate") or 0,
                        HowManyRated=0,
                        ReviewsCount=0,
                        AboutMe=s["bio"],
                        ExperienceDetails=", ".join(s.get("experienceWith", [])),
                        ServiceOptions=", ".join(s.get("services", [])),
                        ProfilePictureUrl=s.get("imageUrl"),
                        Gender=s.get("gender"),
                        Active=True,
                    ))
                    added_sitter = True

                if signup_data.get("addDog") and signup_data.get("dogs"):
                    for d in signup_data["dogs"]:
                        by = int(d.get("birthYear") or d.get("BirthYear"))
                        bm = int(d.get("birthMonth") or d.get("BirthMonth"))

                        session.add(Dog(
                            UserId=user.Id,
                            Name=d["name"],
                            Breed=d.get("breed"),
                            Size=d["size"],
                            Weight=int(d["weight"]) if d.get("weight") is not None else 0,
                            Age= calc_age_decimal(by, bm),
                            BirthMonth= bm,
                            BirthYear= by,
                            MoreDetails=d.get("moreDetails"),
                            HealthConditions=d.get("healthConditions"),
                            Fixed=bool(d.get("fixed", False)),                      
                            FavoriteActivities=", ".join(d.get("favoriteActivities", [])),
                            RabiesVaccinated=bool(d.get("rabiesVaccinated", False)),
                            Gender=d.get("gender"),
                            BehavioralTraits=", ".join(d.get("behavioralTraits", [])),
                            CreatedAt=datetime.datetime.now(datetime.timezone.utc),
                            ProfilePictureUrl=d.get("imageUrl")                     
                        ))
                        added_dogs += 1
                can_complete = (added_sitter or added_dogs > 0)
                if can_complete:
                    user.IsCompleted = True
                else:
                    user.IsCompleted = False

                session.commit()
                return {
                    "success": True,
                    "isComplete": bool(user.IsCompleted),
                    "added": {"sitter": added_sitter, "dogs": added_dogs},
                    "message": "Signup saved" + (" and user marked complete." if user.IsCompleted else " (needs sitter or at least one dog).")
                }, 200

            except Exception as e:
                session.rollback()
                return {"success": False, "isComplete": False, "message": f"DB insert failed: {str(e)}"}, 500

    @staticmethod
    def geocode_address(city: str, street: str):
        city = (city or "").strip()
        street = (street or "").strip()
        lc = city.lower()
        if lc.endswith(", israel"):
            city = city[:-len(", israel")].strip()
        elif lc.endswith(" israel"):
            city = city[:-len(" israel")].strip()

        address = f"{street}, {city}, Israel".strip(", ")
        api_key = os.getenv("GOOGLE_MAPS_API_KEY")
        url = (
            "https://maps.googleapis.com/maps/api/geocode/json"
            f"?address={requests.utils.quote(address)}&key={api_key}"
        )

        print(f"Calling Google Maps API for: {address}")

        resp = requests.get(url, timeout=8)
        resp.raise_for_status()
        data = resp.json()
        if data.get("status") != "OK" or not data.get("results"):
            raise Exception(f"Geocoding returned no results for: {address}")

        first = data["results"][0]
        loc = first["geometry"]["location"]
        return float(loc["lat"]), float(loc["lng"])


    # @staticmethod
    # def geocode_address(city: str, street: str) -> tuple[float, float]:
    #     city = (city or "").strip()
    #     street = (street or "").strip()
    #     lc = city.lower()
    #     if lc.endswith(", israel"):
    #         city = city[:-len(", israel")].strip()
    #     elif lc.endswith(" israel"):
    #         city = city[:-len(" israel")].strip()

    #     candidates = []
    #     if street and city:
    #         candidates.append(f"{street}, {city}, Israel")
    #     if city:
    #         candidates.append(f"{city}, Israel")

    #     api_key = os.getenv("GOOGLE_MAPS_API_KEY")
    #     if not api_key:
    #         raise Exception("Missing GOOGLE_MAPS_API_KEY")

    #     base = "https://maps.googleapis.com/maps/api/geocode/json"
    #     last_status = None
    #     last_error = None

    #     for addr in candidates:
    #         address_q = addr.replace(' ', '+').replace(',', '%2C')
    #         url = f"{base}?address={address_q}&key={api_key}"

    #         print(f"Calling Google Maps API for: {addr}")
    #         k = (os.getenv("GOOGLE_MAPS_API_KEY") or "")
    #         try:
    #             resp = requests.get(url, timeout=6)
    #         except requests.RequestException as e:
    #             last_status = "REQUEST_EXCEPTION"
    #             last_error = str(e)
    #             continue

    #         if resp.status_code != 200:
    #             last_status = f"HTTP {resp.status_code}"
    #             last_error = resp.text[:400]
    #             continue

    #         data = resp.json()
    #         status = data.get("status")
    #         if status == "OK" and data.get("results"):
    #             loc = data["results"][0]["geometry"]["location"]
    #             return float(loc["lat"]), float(loc["lng"])

    #         last_status = status
    #         last_error = data.get("error_message") or ("No results" if not data.get("results") else "")

    #         if status in {"REQUEST_DENIED", "OVER_QUERY_LIMIT", "INVALID_REQUEST"}:
    #             break

    #     raise Exception(
    #         f"Geocoding failed. status={last_status}, error={last_error}, "
    #         f"city='{city}', street='{street}'"
    #     )

def calc_age_decimal(year: int, month: int) -> Decimal:
    today = datetime.date.today()
    total_months = (today.year - year) * 12 + (today.month - month)
    years = Decimal(total_months) / Decimal(12)
    return years.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)