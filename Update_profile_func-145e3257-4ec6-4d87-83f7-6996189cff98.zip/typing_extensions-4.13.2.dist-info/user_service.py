from db import SessionLocal, Base
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime, timezone

class User(Base):
    __tablename__ = 'Users'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    ProfilePictureUrl = Column(String)
    RegistrationDate = Column(DateTime, nullable=False)
    City = Column(String(50), nullable=False)
    Street = Column(String(50))

    @classmethod
    def check_or_insert_user(cls, user_info):
        with SessionLocal() as session:
            try:
                existing_user = session.query(cls).filter_by(Email=user_info["email"]).first()
                if existing_user:
                    return True  #User already exists

                # Insert user if not found
                user = cls(
                    Name=user_info["name"],
                    Email=user_info["email"],
                    Provider=user_info["provider"],
                    ProviderId=user_info["providerId"],
                    Phone=None,
                    ProfilePictureUrl=None,
                    RegistrationDate=datetime.now(timezone.utc),
                    City=None,
                    Street=None
                )
                session.add(user)
                session.commit()
                return False  #User was inserted
            except (KeyError, SQLAlchemyError) as e:
                session.rollback()
                raise Exception("DB operation failed: " + str(e))
        
