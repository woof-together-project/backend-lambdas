# update_profile_lambda.py
import json
import os
from profile_service import ProfileService

ALLOWED_ORIGINS = os.environ.get("ALLOWED_ORIGINS", "http://localhost:4200,https://main.d3v64w044qjoc9.amplifyapp.com").split(",")

svc = ProfileService()

def _cors_headers(origin: str):
    allowed = {o.strip().rstrip("/") for o in ALLOWED_ORIGINS}
    origin = (origin or "").strip().rstrip("/")

    headers = {
        "Access-Control-Allow-Methods": "DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    }
    if origin in allowed:
        headers["Access-Control-Allow-Origin"] = origin
        headers["Vary"] = "Origin"
    return headers

def _parse_body(event):
    raw = event.get("body", "{}")
    if isinstance(raw, str):
        try:
            return json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            return {}
    return raw or {}

def _ok(headers, body):
    return {"statusCode": 200, "headers": headers, "body": json.dumps(body)}

def _bad(headers, msg, code=400):
    return {"statusCode": code, "headers": headers, "body": json.dumps({"error": msg})}

def _server(headers, err):
    return {"statusCode": 500, "headers": headers, "body": json.dumps({"error": str(err)})}

def lambda_handler(event, context):
    origin = (event.get("headers") or {}).get("origin", "")
    headers = _cors_headers(origin)

    method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
        or "POST"
    )
    if method == "OPTIONS":
        return _ok(headers, "")

    if method != "POST":
        return _bad(headers, f"Method {method} not allowed", 405)

    try:
        body = _parse_body(event)
        email = body.get("email")
        if not email:
            return _bad(headers, "Missing 'email' in body")

        # ---- user/sitter fields (existing) ----
        if body.get("section") in ("general", "sitter"):
            section = body["section"]
            field = body.get("field")
            value = body.get("value")
            if field is None:
                return _bad(headers, "Missing 'field'")

            if section == "general":
                ok, msg = svc.update_user_field(email, field, value)
            else:
                ok, msg = svc.update_sitter_field(email, field, value)

            if not ok:
                return _bad(headers, msg)
            return _ok(headers, {"message": msg})

        # ---- dog entity ----
        if body.get("entity") == "dog":
            action = (body.get("action") or "").lower()

            if action == "create":
                payload = body.get("dog") or {}
                ok, res = svc.create_dog(email, payload)
                if not ok:
                    return _bad(headers, res)
                # return the new id in a few common shapes the client checks
                return _ok(headers, {"message": "created", "dogId": res, "id": res})

            if action == "delete":
                ok, msg = svc.delete_dog(email, dog_id=body.get("dogId"), index=body.get("index"))
                if not ok:
                    return _bad(headers, msg)
                return _ok(headers, {"message": msg})

            # default: update existing dog field (old behavior)
            field = body.get("field")
            value = body.get("value")
            if field is None:
                return _bad(headers, "Missing 'field'")
            ok, msg = svc.update_dog_field(email, field, value,
                                           dog_id=body.get("dogId"),
                                           index=body.get("index"))
            if not ok:
                return _bad(headers, msg)
            return _ok(headers, {"message": msg})

        return _bad(headers, "Invalid payload")

    except Exception as e:
        return _server(headers, e)
