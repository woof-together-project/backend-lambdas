# profile_service.py
from typing import Any, Dict, Optional, Tuple
from sqlalchemy import select
from decimal import Decimal, ROUND_HALF_UP
import datetime
import requests
import os
from db import SessionLocal
from models import User, Sitter, Dog

USER_FIELDS: Dict[str, str] = {
    "name": "Name",
    "phone": "Phone",
    "city": "City",
    "street": "Street",
    "isCompleted": "IsCompleted",
}

SITTER_FIELDS: Dict[str, str] = {
    "experienceYears": "ExperienceYears",
    "availability": "Availability",
    "rate": "Rate",
    "sitterBio": "AboutMe",
    "experienceDetails": "ExperienceDetails",
    "serviceOptions": "ServiceOptions",
    "howManyRated": "HowManyRated",
    "reviewsCount": "ReviewsCount",
    "gender": "Gender",
    "active": "Active",
    "profilePictureUrl": "ProfilePictureUrl",
}

DOG_FIELDS: Dict[str, str] = {
    "name": "Name",
    "breed": "Breed",
    "gender": "Gender",
    "size": "Size",
    "weight": "Weight",
    "age": "Age",
    "birthYear": "BirthYear",
    "birthMonth": "BirthMonth",
    "healthConditions": "HealthConditions",
    "fixed": "Fixed",
    "favoriteActivities": "FavoriteActivities",
    "moreDetails": "MoreDetails",
    "behavioralTraits" : "BehavioralTraits",
    "rabiesVaccinated": "RabiesVaccinated",
    "profilePictureUrl": "ProfilePictureUrl",

}

def _normalize_value_for_column(attr: str, value: Any) -> Any:
    if attr in ("FavoriteActivities", "ServiceOptions", "BehavioralTraits", "ExperienceDetails"):
        if isinstance(value, list):
            return ",".join(map(str, value))
        return value or None
    if attr == "Rate":
        if value is None or value == "":
            return None
        return Decimal(str(value))
    if attr == "Age":
        if value in (None, ""):
            return None
        try:
            d = Decimal(str(value))
            return d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        except Exception:
            return None
    if attr in ("Weight", "ExperienceYears", "HowManyRated", "ReviewsCount"):
        if value is None or value == "":
            return None
        return int(value)
    if attr in ("Fixed", "RabiesVaccinated", "IsCompleted"):
        if isinstance(value, str):
            return value.lower() in ("1", "true", "yes", "y")
        return bool(value)
    return value

class ProfileService:
    def fetch_profile(self, email: str) -> Optional[Dict[str, Any]]:
        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return None

            sitter = session.execute(
                select(Sitter).where(Sitter.UserId == user.Id)
            ).scalar_one_or_none()

            dogs = session.execute(
                select(Dog).where(Dog.UserId == user.Id).order_by(Dog.Id.asc())
            ).scalars().all()

            return {
                "user": self._serialize_user(user),
                "sitter": self._serialize_sitter(sitter) if sitter else None,
                "dogs": [self._serialize_dog(d) for d in dogs],
            }

    def update_user_field(self, email: str, field_key: str, value: Any) -> tuple[bool, str]:
        if field_key not in USER_FIELDS:
            return False, f"Unsupported user field '{field_key}'"
        attr = USER_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(select(User).where(User.Email == email)).scalar_one_or_none()
            if not user:
                return False, "User not found"

            setattr(user, attr, _normalize_value_for_column(attr, value))

            if field_key in ("city", "street"):
                city = user.City or ""
                street = user.Street or ""
                if city and street:
                    try:
                        lat, lng = ProfileService.geocode_address(city, street)
                        user.Latitude = Decimal(str(lat))
                        user.Longitude = Decimal(str(lng))
                        if norm_city:
                            user.City = norm_city
                        if norm_street:
                            user.Street = norm_street
                    except Exception as e:
                        print(f"[profile] geocoding failed for '{street}, {city}': {e}")

            session.commit()
        return True, "updated"


    def _ensure_sitter(self, session, user_id: int) -> Sitter:
        sitter = session.execute(
            select(Sitter).where(Sitter.UserId == user_id)
        ).scalar_one_or_none()
        if not sitter:
            sitter = Sitter(
                UserId=user_id,
                ExperienceYears=0,
                Availability="",
                Rate=Decimal("0"),
                HowManyRated=0,
                ReviewsCount=0,
                AboutMe="",
                ExperienceDetails="",
                ServiceOptions="",
                Active=True,
                Gender="",
                ProfilePictureUrl="",
            )
            session.add(sitter)
            session.flush()
        return sitter

    def update_sitter_field(self, email: str, field_key: str, value: Any) -> Tuple[bool, str]:
        if field_key not in SITTER_FIELDS:
            return False, f"Unsupported sitter field '{field_key}'"
        attr = SITTER_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return False, "User not found"

            sitter = self._ensure_sitter(session, user.Id)
            setattr(sitter, attr, _normalize_value_for_column(attr, value))
            session.commit()
        return True, "updated"

    def update_dog_field(self, email: str, field_key: str, value: Any, *, dog_id=None, index=None) -> Tuple[bool, str]:
        if field_key not in DOG_FIELDS:
            return False, f"Unsupported dog field '{field_key}'"
        attr = DOG_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return False, "User not found"

            dog = None
            if dog_id is not None:
                dog = session.execute(
                    select(Dog).where(Dog.Id == dog_id, Dog.UserId == user.Id)
                ).scalar_one_or_none()
                if not dog:
                    return False, "Dog not found for this user"
            elif index is not None:
                dogs = session.execute(
                    select(Dog).where(Dog.UserId == user.Id).order_by(Dog.Id.asc())
                ).scalars().all()
                if index < 0 or index >= len(dogs):
                    return False, f"Dog index {index} out of range"
                dog = dogs[index]
            else:
                return False, "Missing dogId or index"

            setattr(dog, attr, _normalize_value_for_column(attr, value))
            session.commit()
        return True, "updated"

    # ----- serializers -----
    def _serialize_user(self, u: User) -> Dict[str, Any]:
        return {
            "Id": u.Id,
            "Name": u.Name,
            "Email": u.Email,
            "Provider": u.Provider,
            "ProviderId": u.ProviderId,
            "Phone": u.Phone,
            "ProfilePictureUrl": u.ProfilePictureUrl,
            "RegistrationDate": u.RegistrationDate.isoformat() if isinstance(u.RegistrationDate, datetime.datetime) else str(u.RegistrationDate),
            "City": u.City,
            "Street": u.Street,
            "IsCompleted": bool(u.IsCompleted),
            "Latitude": float(u.Latitude) if u.Latitude is not None else None,
            "Longitude": float(u.Longitude) if u.Longitude is not None else None,
            "Gender": u.Gender,
        }

    def _serialize_sitter(self, s: Sitter) -> Dict[str, Any]:
        return {
            "Id": s.Id,
            "UserId": s.UserId,
            "ExperienceYears": s.ExperienceYears,
            "Availability": s.Availability,
            "Rate": float(s.Rate) if isinstance(s.Rate, (Decimal, float, int)) else None,
            "HowManyRated": s.HowManyRated,
            "ReviewsCount": s.ReviewsCount,
            "AboutMe": s.AboutMe,
            "ExperienceDetails": (s.ExperienceDetails or "").split(",") if s.ExperienceDetails else [],
            "ServiceOptions": (s.ServiceOptions or "").split(",") if s.ServiceOptions else [],
            "Active": bool(s.Active),
            "Gender": s.Gender,
            "ProfilePictureUrl": s.ProfilePictureUrl,
        }

    def _serialize_dog(self, d: Dog) -> Dict[str, Any]:
        return {
            "Id": d.Id,
            "UserId": d.UserId,
            "Name": d.Name,
            "Breed": d.Breed,
            "Size": d.Size,
            "Weight": d.Weight,
            "Age": float(d.Age) if d.Age is not None else None,
            "BirthYear": d.BirthYear,
            "BirthMonth": d.BirthMonth,
            "HealthConditions": d.HealthConditions,
            "Fixed": bool(d.Fixed),
            "FavoriteActivities": (d.FavoriteActivities or "").split(",") if d.FavoriteActivities else [],
            "MoreDetails": d.MoreDetails,
            "RabiesVaccinated": bool(d.RabiesVaccinated),
            "BehavioralTraits": (d.BehavioralTraits or "").split(",") if d.BehavioralTraits else [],
            "Gender": d.Gender,
            "CreatedAt": d.CreatedAt.isoformat() if isinstance(d.CreatedAt, datetime.datetime) else str(d.CreatedAt),
            "ProfilePictureUrl": d.ProfilePictureUrl,
        }


    def create_dog(self, email: str, payload: Dict[str, Any]) -> Tuple[bool, Any]:
        with SessionLocal() as session:
            user = session.execute(select(User).where(User.Email == email)).scalar_one_or_none()
            if not user:
                return False, "User not found"
            
            by = int(payload.get("birthYear"))
            bm = int(payload.get("birthMonth"))

            dog = Dog(
                UserId=user.Id,
                Name=payload.get("name"),
                Breed=payload.get("breed") or None,
                Gender=payload.get("gender") or None,
                Size=payload.get("size") or "",                     
                Weight=int(payload.get("weight") or 0),             
                Age= ProfileService.calc_age_decimal(by, bm),                                     
                BirthYear=by,                                       
                BirthMonth=bm,                                      
                HealthConditions=payload.get("health") or payload.get("healthConditions") or None,
                Fixed=bool(_normalize_value_for_column("Fixed", payload.get("fixed"))),
                RabiesVaccinated=bool(_normalize_value_for_column("RabiesVaccinated", payload.get("rabiesVaccinated"))),
                FavoriteActivities=",".join(payload.get("favoriteActivities", [])),
                BehavioralTraits=",".join(payload.get("behavioralTraits", [])),
                MoreDetails=payload.get("moreDetails") or None,
                CreatedAt=datetime.datetime.utcnow(),
                ProfilePictureUrl=payload.get("profilePictureUrl") or None,
            )
            session.add(dog)
            session.commit()
            return True, dog.Id

    def delete_dog(self, email: str, *, dog_id=None, index=None) -> Tuple[bool, str]:
        with SessionLocal() as session:
            user = session.execute(select(User).where(User.Email == email)).scalar_one_or_none()
            if not user:
                return False, "User not found"

            dog = None
            if dog_id is not None:
                dog = session.execute(select(Dog).where(Dog.Id == dog_id, Dog.UserId == user.Id)).scalar_one_or_none()
                if not dog:
                    return False, "Dog not found for this user"
            elif index is not None:
                dogs = session.execute(select(Dog).where(Dog.UserId == user.Id).order_by(Dog.Id.asc())).scalars().all()
                if index < 0 or index >= len(dogs):
                    return False, f"Dog index {index} out of range"
                dog = dogs[index]
            else:
                return False, "Missing dogId or index"

            session.delete(dog)
            session.commit()
            return True, "deleted"


    # @staticmethod
    # def geocode_address(city, street):
    #     address = f"{street}, {city}, Israel"
    #     print(f"🌐 Calling Google Maps API for: {address}")
    #     api_key = os.getenv("GOOGLE_MAPS_API_KEY") 
    #     url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&key={api_key}"

    #     response = requests.get(url)
    #     if response.status_code != 200:
    #         raise Exception("Geocoding API failed")

    #     data = response.json()
    #     if data["status"] != "OK" or not data["results"]:
    #         raise Exception("Geocoding returned no results")

    #     location = data["results"][0]["geometry"]["location"]
    #     return location["lat"], location["lng"]
    
    @staticmethod
    def geocode_address(city: str, street: str):
        """Geocode and also extract a canonical city and street string.

        Returns: (lat, lng, normalized_city, normalized_street)
        """
        address = f"{street}, {city}, Israel".strip(", ")
        api_key = os.getenv("GOOGLE_MAPS_API_KEY")
        url = (
            "https://maps.googleapis.com/maps/api/geocode/json"
            f"?address={requests.utils.quote(address)}&key={api_key}"
        )

        resp = requests.get(url, timeout=8)
        resp.raise_for_status()
        data = resp.json()
        if data.get("status") != "OK" or not data.get("results"):
            raise Exception(f"Geocoding returned no results for: {address}")

        first = data["results"][0]
        loc = first["geometry"]["location"]
        comps = first.get("address_components", [])

    def pick(*types):
        for c in comps:
            ts = set(c.get("types", []))
            if any(t in ts for t in types):
                return c.get("long_name")
        return None

        # Typical precedence: locality → postal_town → admin areas
        locality = (
            pick("locality")
            or pick("postal_town")
            or pick("administrative_area_level_2")
            or pick("administrative_area_level_1")
        )
        country = pick("country") or "Israel"

        route = pick("route") or ""
        number = pick("street_number") or ""
        normalized_city = f"{locality}, {country}" if locality else f"{city}".strip()
        # Build a readable street like: "Nissim Aloni Street 10, Tel Aviv-Yafo, Israel"
        base_street = (route + (" " + number if number else "")).strip()
        normalized_street = (
            f"{base_street}, {normalized_city}" if base_street else first.get("formatted_address")
        )

        return loc["lat"], loc["lng"], normalized_city, normalized_street


    @staticmethod
    def calc_age_decimal(year: int, month: int) -> Decimal:
        today = datetime.date.today()
        total_months = (today.year - year) * 12 + (today.month - month)
        years = Decimal(total_months) / Decimal(12)
        return years.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)