# models.py
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, ForeignKey,
    Numeric, DECIMAL
)
from db import Base  # ← use the shared Base

class User(Base):
    __tablename__ = 'Users'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    RegistrationDate = Column(DateTime, nullable=False, default=datetime.utcnow)
    City = Column(String(50), nullable=False)
    Street = Column(String(50))
    IsCompleted = Column(Boolean, nullable=False, default=False)
    Latitude = Column(Numeric(18, 15), nullable=True)
    Longitude = Column(Numeric(18, 15), nullable=True)

class Sitter(Base):
    __tablename__ = 'Sitters'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    ExperienceYears = Column(Integer, nullable=False)
    Availability = Column(String(500), nullable=False)
    Rate = Column(DECIMAL(18, 0), nullable=False)
    HowManyRated = Column(Integer, nullable=False)
    ReviewsCount = Column(Integer, nullable=False)
    AboutMe = Column(String, nullable=False)
    ExperienceDetails = Column(String, nullable=False)
    ServiceOptions = Column(String(500), nullable=False)
    ProfilePictureUrl = Column(String(1000))
    Gender = Column(String(50))
    Active = Column(Boolean, nullable=False, default=True)

class Dog(Base):
    __tablename__ = 'Dogs'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    Name = Column(String(500), nullable=False)
    Breed = Column(String(500))
    Size = Column(String(500), nullable=False)
    Weight = Column(Integer, nullable=False)
    Age = Column(DECIMAL(5, 2), nullable=False)
    BirthMonth = Column(Integer, nullable=False)
    BirthYear = Column(Integer, nullable=False)
    HealthConditions = Column(String(500))
    Fixed = Column(Boolean, nullable=False)
    FavoriteActivities = Column(String(1000))
    MoreDetails = Column(String(1000))
    RabiesVaccinated = Column(Boolean, nullable=False)
    BehavioralTraits = Column(String(1000))
    Gender = Column(String(50))
    CreatedAt = Column(DateTime, nullable=False, default=datetime.utcnow)
    ProfilePictureUrl = Column(String(1000))
