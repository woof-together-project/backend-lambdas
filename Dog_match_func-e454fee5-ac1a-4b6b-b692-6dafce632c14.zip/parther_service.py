import os
import math
import requests
from db import SessionLocal, Base
from sqlalchemy import Column, Integer, String, Boolean, DateTime, DECIMAL, ForeignKey
from sqlalchemy import func
from decimal import Decimal, InvalidOperation


class User(Base):
    __tablename__ = 'Users'
    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    RegistrationDate = Column(DateTime, nullable=False)
    City = Column(String(50), nullable=False)
    Street = Column(String(50))
    IsCompleted = Column(Boolean, nullable=False, default=False)
    Latitude = Column(DECIMAL(18, 10), nullable=True)
    Longitude = Column(DECIMAL(18, 10), nullable=True)

class Dog(Base):
    __tablename__ = 'Dogs'
    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    Name = Column(String(500), nullable=False)
    Breed = Column(String(500))
    Size = Column(String(500), nullable=False)           
    Weight = Column(Integer, nullable=False)
    Age = Column(DECIMAL(5, 2), nullable=False)
    MoreDetails = Column(String(1000)) 
    ProfilePictureUrl = Column(String)
    HealthConditions = Column(String(500))
    Fixed = Column(Boolean, nullable=False)
    FavoriteActivities = Column(String(1000))            
    RabiesVaccinated = Column(Boolean, nullable=False)
    CreatedAt = Column(DateTime, nullable=False)
    Gender = Column(String(50))  
    BehavioralTraits = Column(String(1000))

class PartherService:

    @staticmethod
    def haversine(lat1, lon1, lat2, lon2):
        R = 6371  # Earth radius in km
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = (
            math.sin(d_lat / 2) ** 2 +
            math.cos(math.radians(lat1)) *
            math.cos(math.radians(lat2)) *
            math.sin(d_lon / 2) ** 2
        )
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    @staticmethod
    def geocode_address(city, street):
        full_address = f"{street or ''}, {city}"
        params = {
            'address': full_address,
            'key': os.getenv("GOOGLE_MAPS_API_KEY")
        }
        response = requests.get("https://maps.googleapis.com/maps/api/geocode/json", params=params)
        data = response.json()
        if data['status'] == 'OK' and data['results']:
            location = data['results'][0]['geometry']['location']
            return location['lat'], location['lng']
        return None, None
    
    @classmethod
    def get_partners_matching_criteria(cls, payload):
        try:
            with SessionLocal() as session:
                latitude = float(payload.get("latitude"))
                longitude = float(payload.get("longitude"))
                radius = float(payload.get("radius", 0))
                use_radius = not payload.get("noRadiusFilter", False)

                sizes = set(s.strip().lower() for s in payload.get("Size", []) if s)
                breed = (payload.get("Breed") or "").strip().lower()
                min_age = cls._to_decimal(payload.get("AgeMin"))
                max_age = cls._to_decimal(payload.get("AgeMax"))
                min_weight = payload.get("WeightMin")
                max_weight = payload.get("WeightMax")
                city = (payload.get("City") or payload.get("city") or "").strip().lower()

                rabies_vaccinated = payload.get("RabiesVaccinated")
                fixed = payload.get("Fixed")

                activities = set(a.strip().lower() for a in payload.get("FavoriteActivities", []) if a)

                traits_selected = payload.get("behavioralTraits") or payload.get("BehavioralTraits") or []
                behavioral_traits = set(cls._norm(t) for t in traits_selected if t)

                exclude_email = (payload.get("excludeEmail") or "").strip().lower()

                dogs = session.query(Dog).all()
                result = []

                for dog in dogs:
                    owner = session.query(User).filter_by(Id=dog.UserId).first()
                    if not owner:
                        continue

                    if exclude_email and owner.Email and owner.Email.lower() == exclude_email:
                        continue
                    if owner.Latitude is None or owner.Longitude is None:
                        continue

                    # ---- Filters ----
                    if city:
                        if not owner.City or owner.City.strip().lower() != city:
                            continue
                    
                    if sizes and (not dog.Size or dog.Size.strip().lower() not in sizes):
                        continue
                    if breed and (not dog.Breed or dog.Breed.strip().lower() != breed):
                        continue
                    if min_age is not None and dog.Age < min_age:
                        continue
                    if max_age is not None and dog.Age > max_age:
                        continue
                    if min_weight is not None and dog.Weight < int(min_weight):
                        continue
                    if max_weight is not None and dog.Weight > int(max_weight):
                        continue
                    if rabies_vaccinated is not None and bool(dog.RabiesVaccinated) != bool(rabies_vaccinated):
                        continue
                    if fixed is not None and bool(dog.Fixed) != bool(fixed):
                        continue

                    dog_acts = set(x.strip().lower() for x in (dog.FavoriteActivities or "").split(",") if x.strip())
                    if activities and not activities.issubset(dog_acts):
                        continue

                    dog_traits = set(cls._norm(x) for x in (dog.BehavioralTraits or "").split(",") if x.strip())
                    if behavioral_traits and not behavioral_traits.issubset(dog_traits):
                        continue

                    # Distance
                    distance = cls.haversine(latitude, longitude, float(owner.Latitude), float(owner.Longitude))
                    if use_radius and distance > radius:
                        continue

                    result.append({
                        "user_id": owner.Id,
                        "ownerName": owner.Name,
                        "ownerEmail": owner.Email,
                        "city": owner.City,
                        "street": owner.Street,
                        "latitude": float(owner.Latitude),
                        "longitude": float(owner.Longitude),
                        "distanceKm": round(distance, 2),
                        "profilePictureUrl": dog.ProfilePictureUrl,
                        "dogId": dog.Id,
                        "dogName": dog.Name,
                        "breed": dog.Breed,
                        "size": dog.Size,
                        "weight": dog.Weight,
                        "age": float(dog.Age),
                        "moreDetails": dog.MoreDetails,
                        "healthConditions": dog.HealthConditions,
                        "Fixed": bool(dog.Fixed),
                        "gender": dog.Gender,
                        "RabiesVaccinated": bool(dog.RabiesVaccinated),
                        "favoriteActivities": [x.strip() for x in (dog.FavoriteActivities or "").split(",") if x.strip()],
                        "behavioralTraits": [x.strip() for x in (dog.BehavioralTraits or "").split(",") if x.strip()]
                    })

                result.sort(key=lambda x: x["distanceKm"])
                return result

        except Exception as e:
            print("Error while filtering partners:", str(e))
            return []
        
    @classmethod
    def get_all_partner_cities(cls, payload= None):
        try:
            with SessionLocal() as session:
                rows = (
                    session.query(User.City)
                    .join(Dog, Dog.UserId == User.Id)
                    .filter(User.City != None)
                    .distinct()
                    .all()
                )
            return sorted(list({c[0].strip() for c in rows if c[0]}))

        except Exception as e:
            print("Error fetching cities:", str(e))
            return []


    @classmethod
    def get_partners_by_city(cls, payload):
        try:
            city = payload.get("city", "").strip()
            latitude = payload.get("latitude", 0)
            longitude = payload.get("longitude", 0)

            if not city:
                return []

            with SessionLocal() as session:
                rows = (
                    session.query(Dog, User)
                    .join(User, Dog.UserId == User.Id)
                    .filter(func.lower(User.City) == city.lower())
                    .all()
                )

                result = []
                for dog, owner in rows:
                    if owner.Latitude is None or owner.Longitude is None:
                        continue
                    distance = cls.haversine(latitude, longitude, float(owner.Latitude), float(owner.Longitude))

                    dog_acts = set(x.strip().lower() for x in (dog.FavoriteActivities or "").split(",") if x.strip())

                    result.append({
                        "user_id": owner.Id,
                        "ownerName": owner.Name,
                        "ownerEmail": owner.Email,
                        "city": owner.City,
                        "street": owner.Street,
                        "latitude": float(owner.Latitude),
                        "longitude": float(owner.Longitude),
                        "distanceKm": round(distance, 2),
                        "profilePictureUrl": dog.ProfilePictureUrl,
                        "dogId": dog.Id,
                        "dogName": dog.Name,
                        "breed": dog.Breed,
                        "size": dog.Size,
                        "weight": dog.Weight,
                        "age": float(dog.Age),
                        "healthConditions": dog.HealthConditions,
                        "Fixed": bool(dog.Fixed),
                        "favoriteActivities": list(dog_acts),
                        "RabiesVaccinated": bool(dog.RabiesVaccinated)
                    })

                result.sort(key=lambda x: x["distanceKm"])
                return result
                
        except Exception as e:
            print("Error while filtering sitters:", str(e))
            return []

    @staticmethod
    def get_user_location(email: str | None):
        if not email:
            return None
        with SessionLocal() as session:
            user = session.query(User).filter(func.lower(User.Email) == email.strip().lower()).first()
            if not user or user.Latitude is None or user.Longitude is None:
                return None
            return {"lat": float(user.Latitude), "lng": float(user.Longitude)}

    @staticmethod
    def _norm(text: str) -> str:
        """Normalize a free-text label for matching/subset checks."""
        if not text:
            return ""
        s = str(text).strip().lower()
        s = s.replace("_", " ").replace("-", " ")
        s = " ".join(s.split())
        return s

    @staticmethod
    def _to_decimal(val):
        if val in (None, "", "null"):  
            return None
        try:
            return Decimal(str(val))
        except (InvalidOperation, TypeError, ValueError):
            return None
