import json
from parther_service import PartherService

def lambda_handler(event, context):
    origin = event.get("headers", {}).get("origin", "")

    allowed = [
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com"
    ]

    headers = {
        "Access-Control-Allow-Origin": origin if origin in allowed else "",
         'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    }

    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        body = json.loads(event.get("body", "{}"))
        action = body.get("action")
        if action == "getMyLocation":
            loc = PartherService.get_user_location(body.get("email"))
            if not loc:
                return {
                    "statusCode": 404,
                    "headers": headers,
                    "body": json.dumps({"message": "No saved location for this user"})
                }
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps(loc)
            }
        
        elif action == "searchAvailableCitiesInDB":
            partners = PartherService.get_all_partner_cities()

        elif action == "searchByCity":
            partners = PartherService.get_partners_by_city(body)

        else:
            # default: search by criteria + location
            required = ["latitude", "longitude"]
            if not all(k in body for k in required):
                raise Exception("Missing location coordinates")

            partners = PartherService.get_partners_matching_criteria(body)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(partners)
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Could not retrieve partners", "detail": str(e)})
        }
