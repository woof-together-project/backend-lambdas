import json
from user_service import User

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    }

    # Handle preflight request
    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": ""
        }

    try:
        # AWS Lambda test invokes wrap body in a string — extract it
        raw_body = event.get("body", "{}")
        if isinstance(raw_body, str):
            body = json.loads(raw_body)
        else:
            body = raw_body

        user_data = body.get("user")

        if not user_data:
            raise Exception("Missing user data")
        
        exists = User.check_or_insert_user(user_data)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "userExists": exists,
                "message": "User already existed" if exists else "User created"
            })
        }

    except Exception as e:
        print("❌ Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Signup failed", "detail": str(e)})
        }

