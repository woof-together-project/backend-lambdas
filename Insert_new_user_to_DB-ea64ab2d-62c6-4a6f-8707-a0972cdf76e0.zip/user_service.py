# user_service.py
from db import SessionLocal, Base
from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime, timezone

class User(Base):
    __tablename__ = 'Users'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    RegistrationDate = Column(DateTime, nullable=False)
    City = Column(String(50))         
    Street = Column(String(50))    
    IsCompleted = Column(Boolean, nullable=False, default=False)

    @classmethod
    def check_or_insert_user(cls, user_info):
        """
        Ensure a row exists; return {"exists": bool, "is_complete": bool}
        """
        with SessionLocal() as session:
            try:
                provider_id = user_info.get("providerId")
                email = user_info.get("email")
                if not provider_id and not email:
                    raise ValueError("providerId or email required")

                q = None
                if provider_id:
                    q = session.query(cls).filter_by(ProviderId=provider_id).first()
                if not q and email:
                    q = session.query(cls).filter_by(Email=email).first()

                if q:
                    return {"exists": True, "is_complete": bool(q.IsCompleted)}

                user = cls(
                    Name=user_info.get("name") or user_info.get("nickname") or "User",
                    Email=email or "",
                    Provider=user_info.get("provider") or "COGNITO",
                    ProviderId=provider_id or "",
                    Phone=None,
                    RegistrationDate=datetime.now(timezone.utc),
                    City=None,
                    Street=None,
                    IsCompleted=False,
                )
                session.add(user)
                session.commit()
                return {"exists": False, "is_complete": False}

            except (KeyError, SQLAlchemyError, ValueError) as e:
                session.rollback()
                raise Exception("DB operation failed: " + str(e))
