import json, base64, os
from user_service import User

ALLOWED_ORIGINS = {
    "http://localhost:4200",
    "https://main.d3v64w044qjoc9.amplifyapp.com",
}

def _cors_headers(origin: str):
    return {
        "Access-Control-Allow-Origin": origin if origin in ALLOWED_ORIGINS else "",
        "Access-Control-Allow-Methods": "DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Toke",
    }

def _parse_body(event):
    """Return a dict regardless of encoding/shape."""
    body = event.get("body")
    if body is None:
        return {}

    if event.get("isBase64Encoded"):
        try:
            body = base64.b64decode(body).decode("utf-8", "ignore")
        except Exception:
            pass

    if isinstance(body, str):
        try:
            return json.loads(body) if body.strip() else {}
        except Exception:
            print(" Body is not valid JSON. Preview:", body[:200])
            return {}
    elif isinstance(body, dict):
        return body
    else:
        return {}

def lambda_handler(event, context):
    origin = event.get("headers", {}).get("origin", "")
    headers = _cors_headers(origin)

    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        body = _parse_body(event)
        print("Parsed body keys:", list(body.keys()))

        user_data = body.get("user")
        if not user_data:
            print("Missing 'user' in body. Full body preview:", (json.dumps(body)[:400] if isinstance(body, dict) else str(body)[:400]))
            raise ValueError("Missing user data")

        status = User.check_or_insert_user(user_data)  

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "userExists": bool(status.get("exists")),
                "isComplete": bool(status.get("is_complete")),
                "message": "User already existed" if status.get("exists") else "User created"
            }),
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Signup/status failed", "detail": str(e)}),
        }
