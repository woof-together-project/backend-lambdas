import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

BUCKET_NAME = 'woof-together-users-profile-pics'

def lambda_handler(event, context):
    logger.info("Lambda invoked.")
    logger.info("Event received: %s", json.dumps(event))

    origin = event.get("headers", {}).get("origin", "")
    
    allowed = [
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com/"
    ]

    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        logger.info("Handling CORS preflight (OPTIONS) request")
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": origin if origin in allowed else "",
                "Access-Control-Allow-Methods": "OPTIONS,GET,POST",
                "Access-Control-Allow-Headers": "*"
            },
            "body": json.dumps({"message": "CORS preflight OK"})
        }

    try:
        body = json.loads(event['body']) if 'body' in event else event
        file_name = body['fileName']
        file_type = body['fileType']

        logger.info(f"fileName: {file_name}, fileType: {file_type}")

        presigned_url = s3.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': BUCKET_NAME,
                'Key': file_name,
                'ContentType': file_type,
                'ACL': 'public-read'  
            },
            ExpiresIn=300,  # 5 minutes
            HttpMethod='PUT'
        )

        public_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        logger.info(f"Generated presigned PUT URL: {presigned_url}")
        logger.info(f"Public URL: {public_url}")

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": origin if origin in allowed else "",
                "Access-Control-Allow-Methods": "OPTIONS,GET,POST",
                "Access-Control-Allow-Headers": "*"
            },
            "body": json.dumps({
                "url": presigned_url,
                "publicUrl": public_url
            })
        }

    except Exception as e:
        logger.error("Error occurred: %s", str(e))
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": origin if origin in allowed else ""
            },
            "body": json.dumps({"error": str(e)})
        }
