import json
import os
from profile_service import ProfileService

ALLOWED_ORIGINS = os.environ.get("ALLOWED_ORIGINS", "http://localhost:4200,https://main.d3v64w044qjoc9.amplifyapp.com").split(",")

svc = ProfileService()

def _cors_headers(origin: str):
    allowed = {o.strip().rstrip("/") for o in ALLOWED_ORIGINS}
    origin = (origin or "").strip().rstrip("/")

    headers = {
        "Access-Control-Allow-Methods": "DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    }
    if origin in allowed:
        headers["Access-Control-Allow-Origin"] = origin
        headers["Vary"] = "Origin"
    return headers

def _ok(headers, body):
    return {"statusCode": 200, "headers": headers, "body": json.dumps(body)}

def _bad(headers, msg, code=400):
    return {"statusCode": code, "headers": headers, "body": json.dumps({"error": msg})}

def _server(headers, err):
    return {"statusCode": 500, "headers": headers, "body": json.dumps({"error": str(err)})}

def lambda_handler(event, context):
    origin = (event.get("headers") or {}).get("origin", "")
    headers = _cors_headers(origin)

    # Preflight
    method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
        or "GET"
    )
    if method == "OPTIONS":
        return _ok(headers, "")

    if method != "GET":
        return _bad(headers, f"Method {method} not allowed", 405)

    try:
        qs = event.get("queryStringParameters") or {}
        email = qs.get("email")
        if not email:
            return _bad(headers, "Missing 'email'")

        profile = svc.fetch_profile(email)
        if not profile:
            return _bad(headers, "User not found", 404)

        return _ok(headers, profile)

    except Exception as e:
        return _server(headers, e)
