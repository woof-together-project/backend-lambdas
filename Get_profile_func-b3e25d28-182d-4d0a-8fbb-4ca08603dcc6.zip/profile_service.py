# profile_service.py
from typing import Any, Dict, Optional, Tuple
from sqlalchemy import select
from decimal import Decimal, ROUND_HALF_UP
import datetime

from db import SessionLocal
from models import User, Sitter, Dog

USER_FIELDS: Dict[str, str] = {
    "name": "Name",
    "phone": "Phone",
    "city": "City",
    "street": "Street",
    "isCompleted": "IsCompleted",
}

SITTER_FIELDS: Dict[str, str] = {
    "experienceYears": "ExperienceYears",
    "availability": "Availability",
    "rate": "Rate",
    "sitterBio": "AboutMe",
    "experienceDetails": "ExperienceDetails",
    "serviceOptions": "ServiceOptions",
    "howManyRated": "HowManyRated",
    "reviewsCount": "ReviewsCount",
    "profilePictureUrl": "ProfilePictureUrl",
    "gender": "Gender",
    "active": "Active",
}

DOG_FIELDS: Dict[str, str] = {
    "name": "Name",
    "breed": "Breed",
    "gender": "Gender",
    "size": "Size",
    "weight": "Weight",
    "age": "Age",
    "birthYear": "BirthYear",      
    "birthMonth": "BirthMonth",
    "healthConditions": "HealthConditions",
    "fixed": "Fixed",
    "favoriteActivities": "FavoriteActivities",
    "moreDetails": "MoreDetails",
    "behavioralTraits" : "BehavioralTraits",
    "rabiesVaccinated": "RabiesVaccinated",
    "profilePictureUrl": "ProfilePictureUrl",
}

def _normalize_value_for_column(attr: str, value: Any) -> Any:
    if attr in ("FavoriteActivities", "ServiceOptions", "BehavioralTraits", "ExperienceDetails"):
        if isinstance(value, list):
            return ",".join(map(str, value))
        return value or None
    if attr == "Rate":
        if value is None or value == "":
            return None
        return Decimal(str(value))
    if attr == "Age":
        if value in (None, ""):
            return None
        try:
            d = Decimal(str(value))
            return d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        except Exception:
            return None
    if attr in ("Weight", "ExperienceYears", "HowManyRated", "ReviewsCount"):
        if value is None or value == "":
            return None
        return int(value)
    if attr in ("Fixed", "RabiesVaccinated", "IsCompleted"):
        if isinstance(value, str):
            return value.lower() in ("1", "true", "yes", "y")
        return bool(value)
    return value
    

class ProfileService:
    def fetch_profile(self, email: str) -> Optional[Dict[str, Any]]:
        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return None

            sitter = session.execute(
                select(Sitter).where(Sitter.UserId == user.Id)
            ).scalar_one_or_none()

            dogs = session.execute(
                select(Dog).where(Dog.UserId == user.Id).order_by(Dog.Id.asc())
            ).scalars().all()

            self._refresh_dog_ages(session, dogs)

            return {
                "user": self._serialize_user(user),
                "sitter": self._serialize_sitter(sitter) if sitter else None,
                "dogs": [self._serialize_dog(d) for d in dogs],
            }

    def update_user_field(self, email: str, field_key: str, value: Any) -> Tuple[bool, str]:
        if field_key not in USER_FIELDS:
            return False, f"Unsupported user field '{field_key}'"
        attr = USER_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return False, "User not found"

            setattr(user, attr, _normalize_value_for_column(attr, value))
            session.commit()
        return True, "updated"

    def _ensure_sitter(self, session, user_id: int) -> Sitter:
        sitter = session.execute(
            select(Sitter).where(Sitter.UserId == user_id)
        ).scalar_one_or_none()
        if not sitter:
            sitter = Sitter(
                UserId=user_id,
                ExperienceYears=0,
                Availability="",
                Rate=Decimal("0"),
                HowManyRated=0,
                ReviewsCount=0,
                AboutMe="",
                ExperienceDetails="",
                ServiceOptions="",
                ProfilePictureUrl="",
                Gender="",
                Active=True,
            )
            session.add(sitter)
            session.flush()
        return sitter

    def update_sitter_field(self, email: str, field_key: str, value: Any) -> Tuple[bool, str]:
        if field_key not in SITTER_FIELDS:
            return False, f"Unsupported sitter field '{field_key}'"
        attr = SITTER_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return False, "User not found"

            sitter = self._ensure_sitter(session, user.Id)
            setattr(sitter, attr, _normalize_value_for_column(attr, value))
            session.commit()
        return True, "updated"

    def update_dog_field(self, email: str, field_key: str, value: Any, *, dog_id=None, index=None) -> Tuple[bool, str]:
        if field_key not in DOG_FIELDS:
            return False, f"Unsupported dog field '{field_key}'"
        attr = DOG_FIELDS[field_key]

        with SessionLocal() as session:
            user = session.execute(
                select(User).where(User.Email == email)
            ).scalar_one_or_none()
            if not user:
                return False, "User not found"

            dog = None
            if dog_id is not None:
                dog = session.execute(
                    select(Dog).where(Dog.Id == dog_id, Dog.UserId == user.Id)
                ).scalar_one_or_none()
                if not dog:
                    return False, "Dog not found for this user"
            elif index is not None:
                dogs = session.execute(
                    select(Dog).where(Dog.UserId == user.Id).order_by(Dog.Id.asc())
                ).scalars().all()
                if index < 0 or index >= len(dogs):
                    return False, f"Dog index {index} out of range"
                dog = dogs[index]
            else:
                return False, "Missing dogId or index"

            setattr(dog, attr, _normalize_value_for_column(attr, value))
            if attr in ("BirthYear", "BirthMonth") and dog.BirthYear and dog.BirthMonth:
                dog.Age = ProfileService.calc_age_decimal(int(dog.BirthYear), int(dog.BirthMonth))
            session.commit()
        return True, "updated"

    # ----- serializers -----
    def _serialize_user(self, u: User) -> Dict[str, Any]:
        return {
            "Id": u.Id,
            "Name": u.Name,
            "Email": u.Email,
            "Provider": u.Provider,
            "ProviderId": u.ProviderId,
            "Phone": u.Phone,
            "RegistrationDate": u.RegistrationDate.isoformat() if isinstance(u.RegistrationDate, datetime.datetime) else str(u.RegistrationDate),
            "City": u.City,
            "Street": u.Street,
            "IsCompleted": bool(u.IsCompleted),
            "Latitude": float(u.Latitude) if u.Latitude is not None else None,
            "Longitude": float(u.Longitude) if u.Longitude is not None else None,
        }

    def _serialize_sitter(self, s: Sitter) -> Dict[str, Any]:
        return {
            "Id": s.Id,
            "UserId": s.UserId,
            "ExperienceYears": s.ExperienceYears,
            "Availability": s.Availability,
            "Rate": float(s.Rate) if isinstance(s.Rate, (Decimal, float, int)) else None,
            "HowManyRated": s.HowManyRated,
            "ReviewsCount": s.ReviewsCount,
            "AboutMe": s.AboutMe,
            "ExperienceDetails": s.ExperienceDetails,
            "ServiceOptions": (s.ServiceOptions or "").split(",") if s.ServiceOptions else [],
            "ProfilePictureUrl": s.ProfilePictureUrl,
            "Gender": s.Gender,
            "Active": bool(s.Active),
        }

    def _serialize_dog(self, d: Dog) -> Dict[str, Any]:
        return {
            "Id": d.Id,
            "UserId": d.UserId,
            "Name": d.Name,
            "Breed": d.Breed,
            "Size": d.Size,
            "Weight": d.Weight,
            "Age": float(d.Age) if d.Age is not None else None,
            "BirthYear": d.BirthYear,          
            "BirthMonth": d.BirthMonth,  
            "HealthConditions": d.HealthConditions,
            "Fixed": bool(d.Fixed),
            "FavoriteActivities": (d.FavoriteActivities or "").split(",") if d.FavoriteActivities else [],
            "MoreDetails": d.MoreDetails,
            "RabiesVaccinated": bool(d.RabiesVaccinated),
            "BehavioralTraits": (d.BehavioralTraits or "").split(",") if d.BehavioralTraits else [],
            "Gender": d.Gender,
            "CreatedAt": d.CreatedAt.isoformat() if isinstance(d.CreatedAt, datetime.datetime) else str(d.CreatedAt),
            "ProfilePictureUrl": d.ProfilePictureUrl,
        }

    def _refresh_dog_ages(self, session, dogs: list[Dog]) -> None:
        changed = False
        for d in dogs:
            if d.BirthYear and d.BirthMonth:
                new_age = ProfileService.calc_age_decimal(int(d.BirthYear), int(d.BirthMonth))
                if d.Age != new_age:
                    d.Age = new_age
                    changed = True
        if changed:
            session.commit()

    @staticmethod
    def calc_age_decimal(year: int, month: int) -> Decimal:
        today = datetime.date.today()
        total_months = (today.year - year) * 12 + (today.month - month)
        years = Decimal(total_months) / Decimal(12)
        return years.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)