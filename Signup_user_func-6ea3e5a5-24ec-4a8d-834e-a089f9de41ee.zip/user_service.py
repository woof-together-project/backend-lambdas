from db import SessionLocal, Base
from sqlalchemy import Column, Integer, String, DateTime, Boolean, DECIMAL, ForeignKey, Numeric
from sqlalchemy.exc import SQLAlchemyError
import datetime
from decimal import Decimal, ROUND_HALF_UP

class Sitter(Base):
    __tablename__ = 'Sitters'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    ExperienceYears = Column(Integer, nullable=False)
    Availability = Column(String(500), nullable=False)
    Rate = Column(DECIMAL(18, 0), nullable=False)
    HowManyRated = Column(Integer, nullable=False)
    ReviewsCount = Column(Integer, nullable=False)
    AboutMe = Column(String, nullable=False)
    ExperienceDetails = Column(String, nullable=False)
    ServiceOptions = Column(String(500), nullable=False)
    ProfilePictureUrl = Column(String)
    Gender = Column(String(50)) 
    Active = Column(Boolean, nullable=False, default=True)

class Dog(Base):
    __tablename__ = 'Dogs'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    UserId = Column(Integer, ForeignKey("Users.Id"), nullable=False)
    Name = Column(String(500), nullable=False)
    Breed = Column(String(500))
    Size = Column(String(500), nullable=False)
    Weight = Column(Integer, nullable=False)
    Age = Column(DECIMAL(5, 2), nullable=False)
    BirthYear = Column(Integer, nullable=False)
    BirthMonth = Column(Integer, nullable=False)
    BehavioralTraits = Column(String(1000))
    HealthConditions = Column(String(500))
    Fixed = Column(Boolean, nullable=False)
    FavoriteActivities = Column(String(1000))
    MoreDetails = Column(String(1000))
    RabiesVaccinated = Column(Boolean, nullable=False)
    Gender = Column(String(50))
    CreatedAt = Column(DateTime, nullable=False)
    ProfilePictureUrl = Column(String)

class User(Base):
    __tablename__ = 'Users'

    Id = Column(Integer, primary_key=True, autoincrement=True)
    Name = Column(String(500), nullable=False)
    Email = Column(String(500), nullable=False)
    Provider = Column(String(50), nullable=False)
    ProviderId = Column(String(500), nullable=False)
    Phone = Column(String(50))
    RegistrationDate = Column(DateTime, nullable=False)
    City = Column(String(50), nullable=False)
    Street = Column(String(50))
    IsCompleted = Column(Boolean, nullable=False, default=False)
    Latitude = Column(Numeric(18, 15), nullable=True)
    Longitude = Column(Numeric(18, 15), nullable=True)

    @classmethod
    def insert_full_signup(cls, signup_data, user_info):
        with SessionLocal() as session:
            try:
                user = session.query(cls).filter_by(Email=user_info["email"]).first()
                if not user:
                    raise Exception(f"User with email {user_info['email']} not found")
                if user.IsCompleted:
                    return user.Id

                user.Phone = signup_data.get("phone")
                user.City = signup_data["city"]
                user.Street = signup_data.get("street")
                user.Latitude = signup_data.get("latitude")
                user.Longitude = signup_data.get("longitude")
                user.IsCompleted = True

                if signup_data.get("isSitter") and signup_data.get("sitterDetails"):
                    s = signup_data["sitterDetails"]
                    session.add(Sitter(
                        UserId=user.Id,
                        ExperienceYears=int(s["experience"]),
                        Availability=s["availability"],
                        Rate=s.get("rate") or 0,
                        HowManyRated=0,
                        ReviewsCount=0,
                        AboutMe=s["bio"],
                        ExperienceDetails=", ".join(s.get("experienceWith", [])),
                        ServiceOptions=", ".join(s.get("services", [])),
                        ProfilePictureUrl=s.get("imageUrl"),
                        Active=True,
                    ))

                if signup_data.get("addDog") and signup_data.get("dogs"):
                    for d in signup_data["dogs"]:
                        
                        by = int(d.get("birthYear") or d.get("BirthYear"))
                        bm = int(d.get("birthMonth") or d.get("BirthMonth"))

                        session.add(Dog(
                            UserId=user.Id,
                            Name=d["name"],
                            Breed=d.get("breed"),
                            Size=d["size"],
                            Weight=d["weight"],
                            Age= calc_age_decimal(by, bm),
                            BirthMonth = bm,
                            BirthYear = by,
                            MoreDetails=d.get("moreDetails"),
                            HealthConditions=d.get("healthConditions"),
                            Fixed=bool(d.get("fixed", False)),                      
                            FavoriteActivities=", ".join(d.get("favoriteActivities", [])),
                            RabiesVaccinated=bool(d.get("rabiesVaccinated", False)), 
                            CreatedAt=datetime.datetime.now(datetime.timezone.utc),
                            Gender=d.get("gender"),
                            BehavioralTraits=", ".join(d.get("behavioralTraits", [])),
                            ProfilePictureUrl=d.get("imageUrl")                      
                        ))

                session.commit()
                return user.Id
            except (KeyError, SQLAlchemyError) as e:
                session.rollback()
                raise Exception("DB insert failed: " + str(e))
            
def calc_age_decimal(year: int, month: int) -> Decimal:
    today = datetime.date.today()
    total_months = (today.year - year) * 12 + (today.month - month)
    years = Decimal(total_months) / Decimal(12)
    return years.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)