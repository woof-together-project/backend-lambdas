from db import SessionLocal
from user_service import User, Sitter, Dog
import datetime
import requests
import os
from decimal import Decimal, ROUND_HALF_UP

class SignupService:
    @staticmethod
    def complete_signup(email: str, signup_data: dict) -> str:
        print(f"Lambda execution started for email: {email}")
        print(f"Received signup data: {signup_data}")

        if not (signup_data.get("isSitter") or (signup_data.get("addDog") and signup_data.get("dogs"))):
            return {
                "success": False,
                "isComplete": False,
                "message": "You must add a dog or mark yourself as a sitter to complete signup."
            }, 200

        with SessionLocal() as session:
            try:
                user = session.query(User).filter_by(Email=email).first()
                print(f"isCompleted: {user.IsCompleted if user else 'No user found'}")

                if not user:
                    return {
                        "success": False,
                        "message": f"No user found with email: {email}",
                        "isComplete": False
                    }, 404

                user.Phone = signup_data.get("phone")
                user.City = signup_data.get("city")
                user.Street = signup_data.get("street")
                
                try:
                    if user.City and user.Street:
                        print(f"Attempting to geocode: {user.Street}, {user.City}")
                        lat, lng = SignupService.geocode_address(user.City, user.Street)
                        print(f"Google returned coordinates: {lat}, {lng}")
                        if lat is not None and lng is not None:
                            user.Latitude = Decimal(str(lat))
                            user.Longitude = Decimal(str(lng))
                            print(f"Saved coordinates to user: {user.Latitude}, {user.Longitude}")
                        else:
                            raise ValueError("Invalid coordinates returned from geocoding.")
                    else:
                        print(f"Missing city or street: City='{user.City}' Street='{user.Street}'")
                except Exception as e:
                    print(f"Geocoding exception: {str(e)}")
                    raise Exception("Could not resolve address to coordinates.")


                added_sitter = False
                added_dogs   = 0

                if signup_data.get("isSitter") and signup_data.get("sitterDetails"):
                    s = signup_data["sitterDetails"]
                    session.add(Sitter(
                        UserId=user.Id,
                        ExperienceYears=int(s["experience"]),
                        Availability=s["availability"],
                        Rate=s.get("rate") or 0,
                        HowManyRated=0,
                        ReviewsCount=0,
                        AboutMe=s["bio"],
                        ExperienceDetails=", ".join(s.get("experienceWith", [])),
                        ServiceOptions=", ".join(s.get("services", [])),
                        ProfilePictureUrl=s.get("imageUrl"),
                        Gender=s.get("gender"),
                        Active=True,
                    ))
                    added_sitter = True

                if signup_data.get("addDog") and signup_data.get("dogs"):
                    for d in signup_data["dogs"]:
                        by = int(d.get("birthYear") or d.get("BirthYear"))
                        bm = int(d.get("birthMonth") or d.get("BirthMonth"))

                        session.add(Dog(
                            UserId=user.Id,
                            Name=d["name"],
                            Breed=d.get("breed"),
                            Size=d["size"],
                            Weight=int(d["weight"]) if d.get("weight") is not None else 0,
                            Age= calc_age_decimal(by, bm),
                            BirthMonth= bm,
                            BirthYear= by,
                            MoreDetails=d.get("moreDetails"),
                            HealthConditions=d.get("healthConditions"),
                            Fixed=bool(d.get("fixed", False)),                      
                            FavoriteActivities=", ".join(d.get("favoriteActivities", [])),
                            RabiesVaccinated=bool(d.get("rabiesVaccinated", False)),
                            Gender=d.get("gender"),
                            BehavioralTraits=", ".join(d.get("behavioralTraits", [])),
                            CreatedAt=datetime.datetime.now(datetime.timezone.utc),
                            ProfilePictureUrl=d.get("imageUrl")                     
                        ))
                        added_dogs += 1
                can_complete = (added_sitter or added_dogs > 0)
                if can_complete:
                    user.IsCompleted = True
                else:
                    user.IsCompleted = False

                session.commit()
                return {
                    "success": True,
                    "isComplete": bool(user.IsCompleted),
                    "added": {"sitter": added_sitter, "dogs": added_dogs},
                    "message": "Signup saved" + (" and user marked complete." if user.IsCompleted else " (needs sitter or at least one dog).")
                }, 200

            except Exception as e:
                session.rollback()
                return {"success": False, "isComplete": False, "message": f"DB insert failed: {str(e)}"}, 500
            
    @staticmethod
    def geocode_address(city, street):
        address = f"{street}, {city}, Israel"
        print(f" Calling Google Maps API for: {address}")
        api_key = os.getenv("GOOGLE_MAPS_API_KEY") 
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&key={api_key}"

        response = requests.get(url)
        if response.status_code != 200:
            raise Exception("Geocoding API failed")

        data = response.json()
        if data["status"] != "OK" or not data["results"]:
            raise Exception("Geocoding returned no results")

        location = data["results"][0]["geometry"]["location"]
        return location["lat"], location["lng"]

def calc_age_decimal(year: int, month: int) -> Decimal:
    today = datetime.date.today()
    total_months = (today.year - year) * 12 + (today.month - month)
    years = Decimal(total_months) / Decimal(12)
    return years.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)