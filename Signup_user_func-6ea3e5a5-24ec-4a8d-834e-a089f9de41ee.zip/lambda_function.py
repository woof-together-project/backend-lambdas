import json
import base64
from signup_service import SignupService

def lambda_handler(event, context):
    allowed = [
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com"
    ]
    origin = event.get("headers", {}).get("origin", "")
    headers = {
        "Access-Control-Allow-Origin": origin if origin in allowed else "",
        "Access-Control-Allow-Methods": "DELETE,GET,HEAD,OPTIONS,PUT,POST,PATCH",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Toke",
        "Content-Type": "application/json"
    }

    method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod")
        or ""
    ).upper()

    if method == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        body_raw = event.get("body") or "{}"
        if event.get("isBase64Encoded"):
            body_raw = base64.b64decode(body_raw).decode("utf-8")

        body = json.loads(body_raw)

        email = body.get("email")
        signup_data = body.get("signupData")

        if not email or not isinstance(signup_data, dict):
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"success": False, "isComplete": False,
                                    "message": "Missing 'email' or invalid 'signupData'."})
            }

        resp_body, status_code = SignupService.complete_signup(email, signup_data)

        if not isinstance(resp_body, dict):
            resp_body = {"success": True, "message": str(resp_body)}

        return {
            "statusCode": int(status_code) if isinstance(status_code, int) else 200,
            "headers": headers,
            "body": json.dumps(resp_body)
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({
                "success": False,
                "isComplete": False,
                "message": "Signup failed",
                "detail": str(e)
            })
        }
