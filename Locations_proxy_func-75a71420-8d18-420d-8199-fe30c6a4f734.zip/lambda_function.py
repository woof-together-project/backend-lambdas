import json, os, urllib.parse, urllib.request, re

API_KEY = os.environ["GOOGLE_MAPS_API_KEY"]
BASE = "https://maps.googleapis.com/maps/api/place"   


def http_get(url: str):
    with urllib.request.urlopen(url) as resp:
        return json.loads(resp.read())


def autocomplete(q: str, session_token: str, types: str | None,
                 locationbias: str | None = None,
                 components: str = "country:il"):
    """
    types:
      - None              -> for city search (don't use deprecated '(cities)')
      - 'address'         -> for street/address search
    """
    params = {
        "input": q,
        "key": API_KEY,
        "sessiontoken": session_token,
        "components": components
    }
    if types:
        params["types"] = types
    if locationbias:
        params["locationbias"] = locationbias

    url = f"{BASE}/autocomplete/json?{urllib.parse.urlencode(params)}"
    return http_get(url)


def details(place_id: str, session_token: str):
    params = {
        "place_id": place_id,
        "key": API_KEY,
        "sessiontoken": session_token,
        "fields": "place_id,name,formatted_address,geometry,address_components"
    }
    url = f"{BASE}/details/json?{urllib.parse.urlencode(params)}"
    return http_get(url)


def cors_headers(origin: str):
    allowed = {
        "http://localhost:4200",
        "https://main.d3v64w044qjoc9.amplifyapp.com",
    }
    h_origin = origin if origin in allowed else ""
    return {
        "Access-Control-Allow-Origin": h_origin or "https://main.d3v64w044qjoc9.amplifyapp.com",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
    }


def _norm(s: str) -> str:
    """normalize strings for city matching (keep Hebrew)"""
    s = (s or "").lower().replace("-", " ")
    return re.sub(r"[^0-9a-z\u0590-\u05FF ,]", "", s)


def _aliases(city_name: str) -> set[str]:
    """basic alias expansions for well-known variants"""
    c = _norm(city_name)
    al = {c}
    if "tel aviv" in c:
        al |= {"tel aviv", "tel aviv yafo", "tel aviv-yafo"}
    return al


def _response(origin: str, status_code: int, body: dict):
    return {"statusCode": status_code, "headers": cors_headers(origin), "body": json.dumps(body)}


def lambda_handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method")
    origin = (event.get("headers") or {}).get("origin", "")

    if method == "OPTIONS":
        return _response(origin, 200, {})

    qs = event.get("queryStringParameters") or {}
    mode = qs.get("mode")

    try:
        if mode == "autocomplete":
            q      = qs.get("q", "")
            token  = qs.get("token", "anon")
            kind   = qs.get("kind", "city")  # 'city' | 'address'
            city_name = qs.get("cityName")   
            rect_sw   = qs.get("rectSw")     # "lat,lng"
            rect_ne   = qs.get("rectNe")     # "lat,lng"
            center    = qs.get("cityCenter") # "lat,lng"

            locationbias = None
            if rect_sw and rect_ne:
                locationbias = f"rectangle:{rect_sw}|{rect_ne}"
            elif center:
                locationbias = f"circle:20000@{center}"

            api_types = "address" if kind == "address" else None

            data = autocomplete(q, token, api_types, locationbias=locationbias)
            status = data.get("status", "UNKNOWN_ERROR")
            if status != "OK":
                return _response(origin, 200, {"status": status, "predictions": [], "error": data.get("error_message", "")})

            preds = [
                {"description": p.get("description", ""), "place_id": p.get("place_id", "")}
                for p in data.get("predictions", [])
            ]

            if kind == "address" and city_name:
                aliases = _aliases(city_name)
                preds = [p for p in preds if any(a in _norm(p["description"]) for a in aliases)]

            return _response(origin, 200, {"status": "OK", "predictions": preds})

        elif mode == "details":
            pid   = qs.get("place_id")
            token = qs.get("token", "anon")
            if not pid:
                return _response(origin, 400, {"error": "place_id is required"})

            d = details(pid, token)
            r = d.get("result", {})
            geom = (r.get("geometry") or {}).get("location") or {}

            body = {
                "place_id": r.get("place_id"),
                "name": r.get("name"),
                "formatted_address": r.get("formatted_address"),
                "lat": geom.get("lat"),
                "lng": geom.get("lng"),
                "address_components": r.get("address_components", []),
                "geometry": {
                    "viewport": (r.get("geometry") or {}).get("viewport", {})
                }
            }
            return _response(origin, 200, body)

        else:
            return _response(origin, 400, {"error": "bad mode"})

    except Exception as e:
        return _response(origin, 500, {"error": str(e)})
